<p>Your Account has been Created. You can Login with credentials Given Below</p>

<table border='1'>
    <tr>
        <td>Username</td>
        <td><?php echo e($email); ?></td>
    </tr>
    <tr>
        <td>Password</td>
        <td><?php echo e($password); ?></td>
    </tr>
</table><?php /**PATH /home/q75gxm6ez3uc/public_html/middle/resources/views/memberCreateMail.blade.php ENDPATH**/ ?>