<p>A new Task has been assigned to you. Login To your App to view</p>

<table border='1'>
    <tr>
        <th>Task</th>
        <th>Region</th>
        <th>City</th>
        <th>Start Date</th>
        <th>Due Date</th>
        <th>Description</th>
    </tr>
    <tr>
        <td><?php echo e($task); ?></td>
        <td><?php echo e($region); ?></td>
        <td><?php echo e($city); ?></td>
        <td><?php echo e($startDate); ?></td>
        <td><?php echo e($dueDate); ?></td>
        <td><?php echo e($description); ?></td>
    </tr>
</table>

<?php if(count($snags) > 0){ ?>

    <p>Associated Snags</p>
    
    <table border="1">
        
        <tr>
            <th>Name</th>
            <th>Area</th>
            <th>Location</th>
        </tr>
        
        <?php foreach($snags as $snag){ ?>

            <tr>
                <td><?php echo $snag['q_name'] ?></td>
                <td><?php echo $snag['Area'] ?></td>
                <td><a href="http://www.google.com/maps/place/<?php echo json_decode($snag['position'], true)['lat'] ?>,<?php echo json_decode($snag['position'], true)['lng'] ?>">Show On Map</a></td>
            </tr>
        
        <?php } ?>
    
    </table>

<?php } ?><?php /**PATH /home/q75gxm6ez3uc/public_html/middle/resources/views/taskAssignedMail.blade.php ENDPATH**/ ?>