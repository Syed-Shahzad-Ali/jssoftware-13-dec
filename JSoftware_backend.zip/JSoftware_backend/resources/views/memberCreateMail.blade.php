<p>Your Account has been Created. You can Login with credentials Given Below</p>

<table border='1'>
    <tr>
        <td>Username</td>
        <td>{{$email}}</td>
    </tr>
    <tr>
        <td>Password</td>
        <td>{{$password}}</td>
    </tr>
</table>